# Team Member Photos

Place team member photos here:
- sarah-chen.jpg
- marcus-johnson.jpg
- priya-patel.jpg
- david-kim.jpg
- emma-wilson.jpg
